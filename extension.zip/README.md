# Canvas Quiz Saver
Fork of the one available on the [webstore](https://chrome.google.com/webstore/detail/canvas-quiz-loader/pfagnepdndhkmilceinbebdfbmiddagl)   
Adds Bug Fixes and new features   

To install download the [CRX file](https://wmeluna.com/canvas-saver-ext/extension.crx), then go to `chrome://extensions`   
Toggle on Developer mode, then drag the downloaded file onto the page.   