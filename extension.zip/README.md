# Canvas Quiz Saver
Edit of the one available on the [webstore](https://chrome.google.com/webstore/detail/canvas-quiz-loader/pfagnepdndhkmilceinbebdfbmiddagl)   
Adds Bug Fixes and new features   